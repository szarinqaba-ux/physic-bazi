import "./globals.css";import Header from "@/components/Header";import type {Metadata} from "next";
export const metadata:Metadata={title:"فیزیک‌بازی",description:"فیزیک نور و برق به زبان دری افغانستان"};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="fa-AF" dir="rtl"><body><Header/><main>{children}</main></body></html>}
