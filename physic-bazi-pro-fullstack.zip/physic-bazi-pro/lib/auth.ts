import {cookies} from "next/headers";
import {jwtVerify,SignJWT} from "jose";
import bcrypt from "bcryptjs";
import {db} from "./db";
const secret=new TextEncoder().encode(process.env.AUTH_SECRET||"development-secret-change-me");
export async function hashPassword(p:string){return bcrypt.hash(p,12)}
export async function verifyPassword(p:string,h:string){return bcrypt.compare(p,h)}
export async function createSession(userId:string){
 const token=await new SignJWT({userId}).setProtectedHeader({alg:"HS256"}).setIssuedAt().setExpirationTime("30d").sign(secret);
 const jar=await cookies();jar.set("pb_session",token,{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",path:"/",maxAge:60*60*24*30});
}
export async function getUser(){
 try{const jar=await cookies();const token=jar.get("pb_session")?.value;if(!token)return null;const {payload}=await jwtVerify(token,secret);if(typeof payload.userId!=="string")return null;return db.user.findUnique({where:{id:payload.userId},select:{id:true,name:true,email:true,xp:true,level:true,isAdmin:true}})}catch{return null}
}
export async function logout(){(await cookies()).delete("pb_session")}
